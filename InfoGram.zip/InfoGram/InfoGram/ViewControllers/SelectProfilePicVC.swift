//
//  SelectProfilePicVC.swift
//  InfoGram
//
//  Created by User on 11/20/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit




class SelectProfilePicVC : UIViewController {
    
    
    
    lazy var imagepicker: UIImagePickerController = {
        var picker = UIImagePickerController()
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        picker.modalPresentationStyle = .fullScreen
        picker.delegate = self
        return picker
    }()
    
    let avatar : UIImageView = {
        var imageview = UIImageView()
        imageview.layer.cornerRadius = 100
        imageview.clipsToBounds = true
        imageview.image = UIImage(named: "blankavatar")
        imageview.isUserInteractionEnabled = true
        imageview.contentMode = .scaleAspectFill
        return imageview
    }()
    
    let selectAvatarButton: AppButton = {
        var button = AppButton(title: "Select avatar")
        return button
    }()
    
    
    let skipButton: AppButton2 = {
          var button = AppButton2(title: "Skip")
          return button
      }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        
        setupViews()
    }
    
    
    func setupViews(){
        
        self.view.backgroundColor = .groupTableViewBackground
        
        avatar.add(self.view)
        selectAvatarButton.add(self.view)
        skipButton.add(self.view)
        
        selectAvatarButton.anchor(height: 50, width: 250, top: nil, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: self.view.centerYAnchor)
        selectAvatarButton.addTarget(self, action: #selector(selectavatar(button:)), for: .touchUpInside)
        
        avatar.anchor(height: 200, width: 200, top: nil, bottom: selectAvatarButton.topAnchor, bottomcontant: -50, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
        avatar.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(avatartapp(view:))))
        
        
        skipButton.anchor(height: 50, width: 250, top: selectAvatarButton.bottomAnchor, topcontant: 50, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
        skipButton.addTarget(self, action: #selector(skip(button:)), for: .touchUpInside)
        
    }
    
    
    @objc func avatartapp(view: UIGestureRecognizer){
        animateIn(button: view.view!) { [weak self] in
            self!.present(self!.imagepicker, animated: true, completion: nil)
        }
    }
    
    
    @objc func selectavatar(button: UIButton){
        animateIn(button: button) {
            
            [weak self] in
            self!.present(self!.imagepicker, animated: true, completion: nil)
            
        }
    }
    
    
    @objc func skip(button: UIButton) {
        animateIn(button: button) { [weak self, weak logininandsignup] in
            
            self?.dismiss(animated: true, completion: {
                var tabarcontroller = Tabbar()
                tabarcontroller.modalPresentationStyle = .fullScreen
                logininandsignup!.present(tabarcontroller, animated: true, completion: nil)
            })
            
            
            
            
        }
    }
    
}





extension SelectProfilePicVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        picker.dismiss(animated: true, completion: nil)
        
        if let photo = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
           
            BackEndService.storeimage(image: photo) { (imageurl) in
               
                BackEndService.updateuser(value: ["profilepic" : imageurl], id: currentuserid!) { [weak self] in
                    
                    self?.avatar.image = photo
                    self?.skipButton.setTitle("Done", for: .normal)
                }
            }
            
        }
        
        if let photo = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                 
                 BackEndService.storeimage(image: photo) { (imageurl) in
                     BackEndService.updateuser(value: ["profilepic" : imageurl], id: currentuserid!) { [weak self] in
                         
                         self?.avatar.image = photo
                         
                     }
                 }
                 
             }
         
    }
    
}
