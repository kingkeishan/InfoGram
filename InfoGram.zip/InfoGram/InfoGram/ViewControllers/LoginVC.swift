//
//  LoginVC.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit




class LoginVC: UIViewController {
    
    var loginfieldtopanchor: NSLayoutConstraint!
    
   lazy var loginfield: LoginField = {
        var field = LoginField()
        field.textfielddelegate = self
        return field
    }()
    
    let LoginButton: AppButton = {
        var button = AppButton(title: "Login")
        button.isEnabled = false
        button.alpha = 0.5
        return button
    }()
    
    let BackArrow = BackArrowButton(type: .system)
   
    var notificationKeybooardUp: Void?
    var notificationKeybooardDown: Void?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notificationKeybooardUp = NotificationCenter.default.addObserver(self, selector: #selector(keybooardwillshow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        notificationKeybooardDown = NotificationCenter.default.addObserver(self, selector: #selector(keybooardwillhide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(viewtapped)))
        
        setupViews()
    }
    
    
    @objc func viewtapped(){
        self.view.endEditing(true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(notificationKeybooardUp)
        NotificationCenter.default.removeObserver(notificationKeybooardDown)
    }
    
    
    @objc func keybooardwillshow(notification: NSNotification){
        
          if let keyboardsize = (notification.userInfo![UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            
            loginfieldtopanchor.constant = -50
            
        }
        
    }
    
    @objc func keybooardwillhide(notification: NSNotification){
        
        loginfieldtopanchor.constant = 0
    }
    
    
    func setupViews(){
        self.view.backgroundColor = .groupTableViewBackground
        loginfield.add(self.view)
        loginfield.anchor(height: 100, width: 300, top: nil, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
        loginfieldtopanchor = loginfield.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        loginfieldtopanchor.isActive = true
        
       
        LoginButton.add(self.view)
        LoginButton.anchor(height: 50, width: 250, top: loginfield.bottomAnchor, topcontant: 50, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
        LoginButton.addTarget(self, action: #selector(login(button:)), for: .touchUpInside)
    
        
        
        BackArrow.add(self.view)
        BackArrow.anchor(height: 50, width: 100, top: self.view.safeAreaLayoutGuide.topAnchor, topcontant: 50, bottom: nil, left: self.view.safeAreaLayoutGuide.leftAnchor, right: nil, centerX: nil, centerY: nil)
        BackArrow.addTarget(self, action: #selector(back(button:)), for: .touchUpInside)
        
    }
    
    @objc func back(button: UIButton) {
        animateIn(button: button) { [weak self] in
            self!.dismiss(animated: true, completion: nil)
        }
    }
    
    @objc func login(button: UIButton){
        animateIn(button: button) { [weak self] in
             
            BackEndService.login(email: self!.loginfield.emailtf.text!, password: self!.loginfield.passwordtf.text!) {
                 
                var tabarcontroller = Tabbar()
                              tabarcontroller.modalPresentationStyle = .fullScreen
                              self?.present(tabarcontroller, animated: true, completion: nil)
                
            }
            
        }
    }
    
}



extension LoginVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if !loginfield.emailtf.text!.isEmpty && !loginfield.passwordtf.text!.isEmpty {
            login(button: LoginButton)
        }else {
            self.view.endEditing(true)
        }
        return true
    }
    
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if range.contains(0) {
            LoginButton.isEnabled = false
            LoginButton.alpha = 0.5
        }else if !loginfield.emailtf.text!.isEmpty && !loginfield.passwordtf.text!.isEmpty {
            LoginButton.isEnabled = true
            LoginButton.alpha = 1
        }
        
        return true
    }
    
    
}
