//
//  InfoGramFeed.swift
//  InfoGram
//
//  Created by User on 11/20/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit
import Firebase




class InfoGramFeed: UITableViewController {
    
    var searchcontroller: UISearchController = {
       let sc = UISearchController()
        sc.hidesNavigationBarDuringPresentation = false
        sc.obscuresBackgroundDuringPresentation = true
        sc.searchBar.placeholder = "Search topic..."
        sc.searchBar.barTintColor = .white
        
        return sc
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNav()
        confugatable()
        
    }
    
    func setupNav(){
        
        self.navigationItem.title = "Infogram Feed"
        self.navigationController?.navigationBar.scrollEdgeAppearance?.backgroundColor = .skyblue()
        self.navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.white]
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationItem.searchController = searchcontroller
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Sign out", style: .plain, target: self, action: #selector(signout))
        
    }
    
    
    @objc func signout(){
        
        do {
        try Auth.auth().signOut()
        if currentuserid == nil {
            self.dismiss(animated: true, completion: nil)
        }
        }catch {
            print(error.localizedDescription)
        }
        
    }
    
    
    func confugatable(){
        self.tableView.separatorStyle = .none
    }
    
    
}
