//
//  ForgotPasswordVC.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit
import ProgressHUD





class ForgotPasswordVC: UIViewController {
    
        var forgotpasswordfieldtopanchor: NSLayoutConstraint!
    
     let BackArrow = BackArrowButton(type: .system)
    
     var notificationKeybooardUp: Void?
     var notificationKeybooardDown: Void?
    
    
    lazy var forgotpasswordfield: ForgotPasswordField = {
          var field = ForgotPasswordField()
          field.textfielddelegate = self
          return field
      }()
    
    
    let SendButton: AppButton = {
        var button = AppButton(title: "Send")
        button.isEnabled = false
        button.alpha = 0.5
        return button
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notificationKeybooardUp = NotificationCenter.default.addObserver(self, selector: #selector(keybooardwillshow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
             
             notificationKeybooardDown = NotificationCenter.default.addObserver(self, selector: #selector(keybooardwillhide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
             
             self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(viewtapped)))
        
        
        setupViews()
        
        
    }
    
    
    func setupViews(){
        self.view.backgroundColor = .groupTableViewBackground
        
        BackArrow.add(self.view)
        BackArrow.anchor(height: 50, width: 100, top: self.view.safeAreaLayoutGuide.topAnchor, topcontant: 50, bottom: nil, left: self.view.safeAreaLayoutGuide.leftAnchor, right: nil, centerX: nil, centerY: nil)
        BackArrow.addTarget(self, action: #selector(back(button:)), for: .touchUpInside)
        
        
        forgotpasswordfield.add(self.view)
          forgotpasswordfield.anchor(height: 50, width: 300, top: nil, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
          forgotpasswordfieldtopanchor = forgotpasswordfield.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
          forgotpasswordfieldtopanchor.isActive = true
          
        
        
        SendButton.add(self.view)
        SendButton.anchor(height: 50, width: 250, top: forgotpasswordfield.bottomAnchor, topcontant: 50, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
        SendButton.addTarget(self, action: #selector(send(button:)), for: .touchUpInside)
        
    }
    
    
    
    @objc func send(button: UIButton){
        animateIn(button: button) { [weak self] in
            BackEndService.passwordreset(email: self!.forgotpasswordfield.emailtf.text!) {
                self!.dismiss(animated: true) {
                  ProgressHUD.showSuccess("A email was sent to reset your password")
                }
            }
            
            
        }
    }
    
    
    @objc func back(button: UIButton) {
        animateIn(button: button) { [weak self] in
            self!.dismiss(animated: true, completion: nil)
        }
    }
    
    
    @objc func viewtapped(){
        self.view.endEditing(true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(notificationKeybooardUp)
        NotificationCenter.default.removeObserver(notificationKeybooardDown)
    }
    
    
    @objc func keybooardwillshow(notification: NSNotification){
        
          if let keyboardsize = (notification.userInfo![UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            
            forgotpasswordfieldtopanchor.constant = -50
            
        }
        
    }
    
    @objc func keybooardwillhide(notification: NSNotification){
        
        forgotpasswordfieldtopanchor.constant = 0
    }
    
    
    
    
    
}




extension ForgotPasswordVC : UITextFieldDelegate {
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if !forgotpasswordfield.emailtf.text!.isEmpty {
            send(button: SendButton)
        }else {
            self.view.endEditing(true)
        }
        return true
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if range.contains(0) {
            SendButton.isEnabled = false
            SendButton.alpha = 0.5
        }else {
            SendButton.isEnabled = true
            SendButton.alpha = 1
        }
        
        return true
    }
    
    
    
}
