//
//  SighnUpVC.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit




class SighnUpVC: UIViewController {
    
    var signupfieldtopanchor: NSLayoutConstraint!
    
       lazy var sighnupfield: SighnUpField = {
         var field = SighnUpField()
         field.textfielddelegate = self
         return field
     }()
    
    
      let SighnUpButton: AppButton = {
          var button = AppButton(title: "Sign up")
          button.isEnabled = false
          button.alpha = 0.5
          return button
      }()
    
    let BackArrow = BackArrowButton(type: .system)
    
    
    var notificationKeybooardUp: Void?
    var notificationKeybooardDown: Void?
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        
        notificationKeybooardUp = NotificationCenter.default.addObserver(self, selector: #selector(keybooardwillshow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
          
          notificationKeybooardDown = NotificationCenter.default.addObserver(self, selector: #selector(keybooardwillhide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
          
          self.view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(viewtapped)))
        
        setupViews()
    }
    
    
    
    @objc func viewtapped(){
        self.view.endEditing(true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(notificationKeybooardUp)
        NotificationCenter.default.removeObserver(notificationKeybooardDown)
    }
    
    
    @objc func keybooardwillshow(notification: NSNotification){
        
          if let keyboardsize = (notification.userInfo![UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            
            signupfieldtopanchor.constant = -150
            
        }
        
    }
    
    @objc func keybooardwillhide(notification: NSNotification){
        
        signupfieldtopanchor.constant = 0
    }
    
    
    
    
    func setupViews(){
        self.view.backgroundColor = .groupTableViewBackground
        sighnupfield.add(self.view)
        sighnupfield.anchor(height: 250, width: 300, top: nil, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: self.view.centerYAnchor)
        signupfieldtopanchor = sighnupfield.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
              signupfieldtopanchor.isActive = true
        
        
        SighnUpButton.add(self.view)
        SighnUpButton.anchor(height: 50, width: 250, top: sighnupfield.bottomAnchor, topcontant: 50, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
        SighnUpButton.addTarget(self, action: #selector(signup(button:)), for: .touchUpInside)
        
        
        BackArrow.add(self.view)
        BackArrow.anchor(height: 50, width: 100, top: self.view.safeAreaLayoutGuide.topAnchor, topcontant: 50, bottom: nil, left: self.view.safeAreaLayoutGuide.leftAnchor, right: nil, centerX: nil, centerY: nil)
        BackArrow.addTarget(self, action: #selector(back(button:)), for: .touchUpInside)
        
    }
    
    @objc func back(button: UIButton) {
        animateIn(button: button) {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    @objc func signup(button: UIButton){
        animateIn(button: button)  {
            [weak self] in
             
            BackEndService.signup(username: self!.sighnupfield.displaynametf.text!, email: self!.sighnupfield.emailtf.text!, language: self!.sighnupfield.languagetf.text!, password: self!.sighnupfield.passwordtf.text!, retypepassword: self!.sighnupfield.retypepasswordtf.text!) {
                 
                self?.navigationController?.pushViewController(SelectProfilePicVC(), animated: true)
                
                
            }
            
            
        }
    }
    
}




extension SighnUpVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if !sighnupfield.emailtf.text!.isEmpty && !sighnupfield.passwordtf.text!.isEmpty {
            signup(button: SighnUpButton)
        }else {
            self.view.endEditing(true)
        }
        return true
    }
    
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if range.contains(0) {
            SighnUpButton.isEnabled = false
            SighnUpButton.alpha = 0.5
        }else if !sighnupfield.emailtf.text!.isEmpty && !sighnupfield.passwordtf.text!.isEmpty && !sighnupfield.displaynametf.text!.isEmpty && !sighnupfield.languagetf.text!.isEmpty && !sighnupfield.retypepasswordtf.text!.isEmpty {
            
            SighnUpButton.isEnabled = true
            SighnUpButton.alpha = 1
        }
        return true
    }
    
    
}
