//
//  LoginAndSignUpVC.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit




class LoginAndSignUpVC : UIViewController {
    
    var Login = LoginButton(type: .system)
    var Signup = SighnUpButton(type: .system)
    var ForgotPasswrod = ForgotPasswordButton(type: .system)
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        logininandsignup = self
        setupViews()
    }
    
    func setupViews(){
        self.view.backgroundColor = .white
        
        Login.add(self.view)
        Login.anchor(height: 50, width: 250, top: nil, bottom: nil, left: nil, right: nil, centerX: self.view!.centerXAnchor, centerY: self.view!.centerYAnchor)
        Login.addTarget(self, action: #selector(login(button:)), for: .touchUpInside)
        
        Signup.add(self.view)
        Signup.anchor(height: 50, width: 250, top: Login.bottomAnchor, topcontant: 50, bottom: nil, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
        Signup.addTarget(self, action: #selector(sighnup(button:)), for: .touchUpInside)
        
        
        ForgotPasswrod.add(self.view)
        ForgotPasswrod.anchor(height: 50, width: 250, top: nil, bottom: self.view.safeAreaLayoutGuide.bottomAnchor, left: nil, right: nil, centerX: self.view.centerXAnchor, centerY: nil)
        ForgotPasswrod.addTarget(self, action: #selector(forgotpassword(button:)), for: .touchUpInside)
        
    }
    
    
    
    @objc func login(button: UIButton){
        animateIn(button: button) {
            let loginvc = LoginVC()
            loginvc.modalPresentationStyle = .fullScreen
            self.present(loginvc, animated: true, completion: nil)
            
            
        }
    }
    
    
    @objc func sighnup(button: UIButton){
        animateIn(button: button) {
             
            let sighnupvc = UINavigationController(rootViewController: SighnUpVC()) 
            sighnupvc.modalPresentationStyle = .fullScreen
            self.present(sighnupvc, animated: true, completion: nil)
                      
            
            
        }
    }
    
    
    @objc func forgotpassword(button: UIButton){
        animateIn(button: button) {
             
            let forgotpasswordvc = ForgotPasswordVC()
            forgotpasswordvc.modalPresentationStyle = .fullScreen
            self.present(forgotpasswordvc, animated: true, completion: nil)
                               
            
        }
    }
    
}






