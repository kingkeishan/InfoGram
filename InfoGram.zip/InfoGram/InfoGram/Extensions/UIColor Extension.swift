//
//  UIColor Extention.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit
import ChameleonFramework






extension UIColor {
    

   static func skyblue() -> UIColor { UIColor.flatSkyBlue() }
  
}
