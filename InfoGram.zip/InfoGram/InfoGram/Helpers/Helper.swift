//
//  Helper.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//


import UIKit
import Firebase



var currentuserid = Auth.auth().currentUser?.uid
var currentuserusername = Auth.auth().currentUser?.displayName
var logininandsignup: LoginAndSignUpVC!



func animateIn(button: UIView, completion: @escaping () -> ()) {
    UIView.animate(withDuration: 0.25, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 10, options: .curveEaseIn, animations: {
         button.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
     }) { (_) in
        animateOut(button: button) {
            completion()
        }
     }
 }
 


fileprivate func animateOut(button: UIView, completion: @escaping () -> ()) {

    UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 10, options: .curveEaseIn, animations: {
         button.transform = CGAffineTransform.identity
     }) { (_) in
          completion()
     }
 }

