//
//  AppDelegate.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit
import Firebase

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        window = UIWindow()
        window?.makeKeyAndVisible()
        window?.rootViewController = LoginAndSignUpVC()
        
        FirebaseApp.configure()
        
        UINavigationBar.appearance().backgroundColor = .skyblue()
        UINavigationBar.appearance().tintColor = .white
        
        
    
        return true
    }



}

