//
//  UserModel.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import Foundation




class UserModel {
    
    var username: String
    var status: String
    var profilepic: String
    var userid: String
    var language: String
    
    init(dictionary: [String : Any]) {
        username = dictionary["username"] as! String
        status = dictionary["status"] as! String
        profilepic = dictionary["profilepic"] as! String
        userid = dictionary["userid"] as! String
        language = dictionary["language"] as! String
    }
    
    
    
    
}
