//
//  BackEndService.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import Firebase
import ProgressHUD

class BackEndService {
    
    
   static func login(email: String, password: String, completion: @escaping () -> ()){
        Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            if let error = error {
                
                  if let autherror = AuthErrorCode(rawValue: error._code) {
                    
                    switch autherror {
                    case .wrongPassword:
                        ProgressHUD.showError("Wrong password")
                    case.invalidEmail:
                        ProgressHUD.showError("Invalid email")
                    case.emailAlreadyInUse:
                        ProgressHUD.showError("Email already in use")
                    case.userNotFound:
                        ProgressHUD.showError("User not found")
                    case.networkError:
                        ProgressHUD.showError("Connection error")
                    default : break
                    }
                
                }
            }else {
                
                completion()
            }
        }
    }
    
    
    
    static func passwordreset(email: String, completion: @escaping () -> ()){
        Auth.auth().sendPasswordReset(withEmail: email) { (error) in
            if let error = error {
                 if let autherror = AuthErrorCode(rawValue: error._code) {
                    switch autherror {
                    case .invalidEmail:
                         ProgressHUD.showError("Invalid email")
                    case.userNotFound:
                        ProgressHUD.showError("User not found")
                        
                    default:
                        break
                    }
                }
                
            }else {
                completion()
            }
        }
    }
    
    
    
    
    static func signup(username: String, email: String, language: String, password: String, retypepassword: String, completion: @escaping () -> ()) {
        
        guard password == retypepassword else {
            ProgressHUD.showError("Password fields do not match")
            return
        }
        
        ProgressHUD.show()
        
        Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
            if let error = error {
                
                if let autherror = AuthErrorCode(rawValue: error._code) {
                             
                             switch autherror {
                             case .weakPassword:
                                 ProgressHUD.showError("Weak password")
                             case.invalidEmail:
                                 ProgressHUD.showError("Invalid email")
                             case.emailAlreadyInUse:
                                 ProgressHUD.showError("Email already in use")
                             case.networkError:
                                 ProgressHUD.showError("Connection error")
                             default : break
                             }
                         
                         }
                
                
            }else {
                
                let user = Auth.auth().currentUser
                           if let user = user {
                               
                               let changerequest = user.createProfileChangeRequest()
                               changerequest.displayName = username
                               changerequest.commitChanges(completion: { (error) in
                                   if let error = error {
                                    print(error.localizedDescription)
                                   }else{
                                    
                                    let ref = Database.database().reference().child("users").child(currentuserid!)
                                    let values: [String: Any] = ["username" : username, "userid" : currentuserid!, "status" : "online", "language" : language]
                                    ref.setValue(values) { (error, reference) in
                                        
                                        if let error = error {
                                            print(error.localizedDescription)
                                        }else {
                                            ProgressHUD.dismiss()
                                            completion()
                                            
                                        }
                                    }
                                    
                                }
                })
            }
        }
    }
   
}
    
    
    static func storeimage(image: UIImage, completion: @escaping (String) -> ()) {
        if let data = image.jpegData(compressionQuality: 0.3) {
        let ref = Storage.storage().reference().child("images").child(UUID().uuidString)
            ref.putData(data, metadata: nil) { (meta, error) in
                if let error = error {
                    print(error.localizedDescription)
                }else {
                    
                    ref.downloadURL { (url, error) in
                        if let error = error {
                            print(error.localizedDescription)
                        }else {
                            completion(url!.absoluteString)
                        }
                    }
                    
                }
            }
    }
}
    
    
    
    static func updateuser(value: [String: Any], id: String, completion: @escaping () -> ()) {
        let ref = Database.database().reference().child("users").child(id)
        ref.updateChildValues(value) { (error, reference) in
            
            if let error = error {
                print(error.localizedDescription)
            }else {
                
                completion()
            }
            
        }
    }
    
    
}
