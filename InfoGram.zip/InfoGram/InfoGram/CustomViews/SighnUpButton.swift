//
//  SighnUpButton.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit




class SighnUpButton : UIButton {
    

    override init(frame: CGRect) {
        super.init(frame: frame)
       
        if frame == .zero {
        self.translatesAutoresizingMaskIntoConstraints = false
        }
        setTitle("Sign up", for: .normal)
        setTitleColor(.skyblue(), for: .normal)
        layer.cornerRadius = 25
        layer.borderColor = UIColor.skyblue().cgColor
        layer.borderWidth = 2
        clipsToBounds = true
        backgroundColor = .clear
        titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
    
    }
    
  
    
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
