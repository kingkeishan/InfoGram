//
//  Tabbar.swift
//  InfoGram
//
//  Created by User on 11/20/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit




class Tabbar: UITabBarController {
    
    
    let infogramfeedVC = UINavigationController(rootViewController: InfoGramFeed())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        infogramfeedVC.tabBarItem.title = ""
        infogramfeedVC.tabBarItem.image = UIImage(named: "socialmedia")
        infogramfeedVC.tabBarItem.imageInsets = .init(top: 10, left: 0, bottom: 10, right: 0)
        
        
        
        tabBar.isTranslucent = false
        tabBar.tintColor = .white
        tabBar.barTintColor = .skyblue()
        viewControllers = [infogramfeedVC]
        
    }
    
    
}
