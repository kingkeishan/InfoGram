//
//  BackArrowButton.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit




class BackArrowButton: UIButton {
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        if frame == .zero {
            translatesAutoresizingMaskIntoConstraints = false
        }
        setImage(UIImage(named: "backarrow"), for: .normal)
        imageView?.contentMode = .scaleAspectFit
        tintColor = UIColor.skyblue()
        
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
