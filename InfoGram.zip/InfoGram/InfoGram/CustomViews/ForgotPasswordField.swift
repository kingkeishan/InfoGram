//
//  ForgotPasswordField.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit


class ForgotPasswordField: UIView {
    
    
    var emailtf: UITextField = {
         var tf = UITextField()
         tf.translatesAutoresizingMaskIntoConstraints = false
         tf.placeholder = "Enter email"
         tf.font = UIFont.boldSystemFont(ofSize: 16)
         tf.keyboardType = .emailAddress
         tf.clearButtonMode = .whileEditing
         tf.textAlignment = .center
         return tf
     }()
    
    
    
    var textfielddelegate: UITextFieldDelegate! {
         didSet {
            emailtf.delegate = textfielddelegate
         }
     }
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        if frame == .zero {
               translatesAutoresizingMaskIntoConstraints = false
           }
           backgroundColor = .white
           layer.cornerRadius = 12
           clipsToBounds = true
           emailtf.add(self)
           emailtf.anchor(height: 50, width: 300, top: self.topAnchor, bottom: nil, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
        
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
