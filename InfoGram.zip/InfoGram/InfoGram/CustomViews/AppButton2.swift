//
//  AppButton2.swift
//  InfoGram
//
//  Created by User on 11/20/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit



class AppButton2: UIButton {
    
    init(title: String) {
        super.init(frame: .zero)
        translatesAutoresizingMaskIntoConstraints = false
        setTitle(title, for: .normal)
        layer.cornerRadius = 25
        clipsToBounds = true
        setTitleColor(.skyblue(), for: .normal)
        backgroundColor = .clear
        layer.borderColor = UIColor.skyblue().cgColor
        layer.borderWidth = 2
        titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
    }
    
 
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
