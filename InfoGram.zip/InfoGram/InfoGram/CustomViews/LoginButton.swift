//
//  LoginButton.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit




class LoginButton : UIButton {
    

    override init(frame: CGRect) {
        super.init(frame: frame)
       
        if frame == .zero {
        self.translatesAutoresizingMaskIntoConstraints = false
        }
        setTitle("Login", for: .normal)
        setTitleColor(.white, for: .normal)
        layer.cornerRadius = 25
        clipsToBounds = true
        backgroundColor = .skyblue()
        titleLabel?.font = UIFont.systemFont(ofSize: 14)
    
    }
    
  
    
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
