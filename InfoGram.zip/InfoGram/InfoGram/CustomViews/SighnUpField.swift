//
//  SighnUpField.swift
//  InfoGram
//
//  Created by User on 11/19/19.
//  Copyright © 2019 User. All rights reserved.
//

import UIKit



class SighnUpField: UIView {
    
    
    var emailtf: UITextField = {
        var tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.placeholder = "Email"
        tf.font = UIFont.boldSystemFont(ofSize: 16)
        tf.keyboardType = .emailAddress
        tf.clearButtonMode = .whileEditing
        tf.textAlignment = .center
        return tf
    }()
    
    
    var displaynametf: UITextField = {
        var tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.placeholder = "Username"
        tf.font = UIFont.boldSystemFont(ofSize: 16)
        tf.keyboardType = .default
        tf.clearButtonMode = .whileEditing
        tf.textAlignment = .center
        return tf
    }()
    
    
    var languagetf: UITextField = {
        var tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.placeholder = "Language"
        tf.font = UIFont.boldSystemFont(ofSize: 16)
        tf.keyboardType = .default
        tf.clearButtonMode = .whileEditing
        tf.textAlignment = .center
        return tf
    }()
    
    
    var passwordtf: UITextField = {
        var tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.placeholder = "Password"
        tf.font = UIFont.boldSystemFont(ofSize: 16)
        tf.keyboardType = .default
        tf.clearButtonMode = .whileEditing
        tf.textAlignment = .center
        tf.isSecureTextEntry = true
        return tf
    }()
    
    var retypepasswordtf: UITextField = {
        var tf = UITextField()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.placeholder = "Retype Password"
        tf.font = UIFont.boldSystemFont(ofSize: 16)
        tf.keyboardType = .default
        tf.clearButtonMode = .whileEditing
        tf.textAlignment = .center
        tf.isSecureTextEntry = true
        
        return tf
    }()
    
    
    
    var textfielddelegate: UITextFieldDelegate! {
         didSet {
            displaynametf.delegate = textfielddelegate
            emailtf.delegate = textfielddelegate
            languagetf.delegate = textfielddelegate
            passwordtf.delegate = textfielddelegate
            retypepasswordtf.delegate = textfielddelegate
         }
     }
    
    
    var seperator: UIView = {
        var view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        if #available(iOS 13.0, *) {
            view.backgroundColor = .separator
        } else {
            view.backgroundColor = .groupTableViewBackground
        }
        return view
    }()
    
    var seperator2: UIView = {
          var view = UIView()
          view.translatesAutoresizingMaskIntoConstraints = false
              if #available(iOS 13.0, *) {
                  view.backgroundColor = .separator
              } else {
                  view.backgroundColor = .groupTableViewBackground
              }
             
          return view
      }()
    
    var seperator3: UIView = {
          var view = UIView()
          view.translatesAutoresizingMaskIntoConstraints = false
              if #available(iOS 13.0, *) {
                  view.backgroundColor = .separator
              } else {
                  view.backgroundColor = .groupTableViewBackground
              }
           
          return view
      }()
    
    var seperator4: UIView = {
          var view = UIView()
          view.translatesAutoresizingMaskIntoConstraints = false
              if #available(iOS 13.0, *) {
                  view.backgroundColor = .separator
              } else {
                  view.backgroundColor = .groupTableViewBackground
              }
        
          return view
      }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        if frame == .zero {
            translatesAutoresizingMaskIntoConstraints = false
        }
        backgroundColor = .white
        layer.cornerRadius = 12
        clipsToBounds = true
        
        displaynametf.add(self)
        displaynametf.anchor(height: 50, width: 300, top: self.topAnchor, bottom: nil, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
              
        
        emailtf.add(self)
        emailtf.anchor(height: 50, width: 300, top: displaynametf.bottomAnchor, bottom: nil, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
        
        
        languagetf.add(self)
        languagetf.anchor(height: 50, width: 300, top: emailtf.bottomAnchor, bottom: nil, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
              
      
        passwordtf.add(self)
        passwordtf.anchor(height: 50, width: 300, top: languagetf.bottomAnchor, bottom: nil, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
        
        
        retypepasswordtf.add(self)
        retypepasswordtf.anchor(height: 50, width: 300, top: nil, bottom: self.bottomAnchor, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
        
        seperator.add(self)
        seperator.anchor(height: 1, width: 300, top: nil, bottom: emailtf.topAnchor, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
        
        seperator2.add(self)
        seperator2.anchor(height: 1, width: 300, top: nil, bottom: languagetf.topAnchor, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
        
        seperator3.add(self)
        seperator3.anchor(height: 1, width: 300, top: nil, bottom: passwordtf.topAnchor, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
        
        seperator4.add(self)
        seperator4.anchor(height: 1, width: 300, top: nil, bottom: retypepasswordtf.topAnchor, left: nil, right: nil, centerX: self.centerXAnchor, centerY: nil)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
